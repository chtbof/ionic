var myJsonData = [{
	"id": "1",
	"longitude": "121.517393",
	"latitude": "25.048336",
	"description": "台北車站",
	"altitude": "100.0",
	"name": "北車"
}, {
	"id": "2",
	"longitude": "121.535356",
	"latitude": "25.030130",
	"description": "大安森林公園",
	"altitude": "100.0",
	"name": "大安公園"
}];